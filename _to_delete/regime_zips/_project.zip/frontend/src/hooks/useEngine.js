import { useCallback, useEffect, useState } from 'react';

// One hook, used by both panels -- which is the second use, so it earns being
// a hook at all (Architecture.md).
const API_BASE = `http://${window.location.hostname}:8100/api`;
const POLL_INTERVAL_MS = 5 * 60 * 1000;

async function getJson(path) {
  const response = await fetch(`${API_BASE}${path}`);
  if (!response.ok) {
    // The API answers 503 with a specific, actionable message when the tables
    // are empty ("run backfill_history.py"). Surfacing it beats "failed to
    // fetch", which sends you looking at the network layer instead.
    let detail = response.statusText;
    try {
      const body = await response.json();
      if (body.detail) detail = body.detail;
    } catch {
      /* non-JSON error body; the status text is all we have */
    }
    throw new Error(detail);
  }
  return response.json();
}

export function useEngine() {
  const [regime, setRegime] = useState(null);
  const [history, setHistory] = useState(null);
  const [tilts, setTilts] = useState(null);
  const [sentiment, setSentiment] = useState(null);
  const [sentimentHistory, setSentimentHistory] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      // Settled rather than all: a missing sentiment table should not blank
      // the regime panel, and vice versa.
      const [r, h, t, s, sh] = await Promise.allSettled([
        getJson('/regime'),
        getJson('/regime/history?months=36'),
        getJson('/regime/tilts'),
        getJson('/sentiment'),
        getJson('/sentiment/history?days=250'),
      ]);
      setRegime(r.status === 'fulfilled' ? r.value : null);
      setHistory(h.status === 'fulfilled' ? h.value : null);
      setTilts(t.status === 'fulfilled' ? t.value : null);
      setSentiment(s.status === 'fulfilled' ? s.value : null);
      setSentimentHistory(sh.status === 'fulfilled' ? sh.value : null);

      const failures = [r, h, t, s, sh].filter((p) => p.status === 'rejected');
      setError(failures.length === 5 ? failures[0].reason.message : '');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [load]);

  return { regime, history, tilts, sentiment, sentimentHistory, error,
           loading, reload: load };
}
