"""JSON-safe conversion for pandas rows.

json.dumps writes bare NaN and Infinity, which no strict JSON parser accepts
-- including the browser's. Everything leaving this API goes through here.
"""

import math

import pandas as pd


def scalar(v):
    """One value -> a JSON-safe Python scalar."""
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return None
    if isinstance(v, pd.Timestamp):
        return v.date().isoformat()
    if pd.isna(v):
        return None
    if hasattr(v, "item"):          # numpy scalar
        v = v.item()
    if isinstance(v, float):
        return None if not math.isfinite(v) else round(v, 6)
    return v


def row(r: pd.Series, timestamp_name: str = "as_of") -> dict:
    """One DataFrame row -> dict, index value included as `timestamp_name`."""
    out = {timestamp_name: scalar(r.name)}
    out.update({str(k): scalar(v) for k, v in r.items()})
    return out


def frame(df: pd.DataFrame, timestamp_name: str = "as_of") -> list[dict]:
    """Whole frame -> list of dicts, oldest first."""
    return [row(r, timestamp_name) for _, r in df.iterrows()]
