"""Nightly worker: ingest the extra FRED series, then recompute both tables.

Scheduling sits after open-finance's own jobs so it reads fresh data rather
than yesterday's. open-finance runs, in order:

    00:05  corporate actions        00:07  intraday partition cleanup
    00:10  daily equity backfill    01:30  FRED macro ingest

So this worker starts at 02:00, and the recompute at 02:30 once its own FRED
fetch has landed.
"""

import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from apscheduler.schedulers.blocking import BlockingScheduler

from worker import extra_series, recompute, tickers

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

STARTUP_DELAY_SECONDS = 10


def nightly() -> None:
    """Ingest, then recompute. One log line per stage, so a partial failure is
    visible in `docker compose logs` without needing the database."""
    try:
        written = extra_series.run_once()
        logger.info("FRED ingest complete: %s", written)
    except Exception as e:
        logger.error("FRED ingest failed: %s", e)

    try:
        counts = recompute.run_all()
        logger.info("Recompute complete: %s", counts)
    except Exception as e:
        logger.error("Recompute failed: %s", e)


def main() -> None:
    logger.info("regime_mapping worker starting up")
    time.sleep(STARTUP_DELAY_SECONDS)

    # Registration is idempotent and cheap, and doing it on every start means
    # a fresh QuestDB volume recovers without a manual step.
    try:
        logger.info("Ticker registration: %s", tickers.register_all())
    except Exception as e:
        logger.error("Ticker registration failed: %s", e)

    nightly()

    scheduler = BlockingScheduler()
    scheduler.add_job(nightly, "cron", hour="2", minute="0",
                      id="ingest-and-recompute")
    logger.info("Worker scheduler active (nightly at 02:00)")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        pass


if __name__ == "__main__":
    main()
