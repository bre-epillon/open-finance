"""The whole chain over synthetic history shaped like the real record.

What this DOES verify: that the pipeline -- registry, monthly resample,
publication lag, per-component normalisation, weighted composite, Delta,
quadrant, and the scoring harness in scripts/validate_history.py -- turns a
macro path with a known shape into the regime labels that shape implies, over
65 years and across real calendar dates.

What it does NOT verify: calibration against the actual economy. The inputs
here are drawn from remembered anchor points, and a test built from the same
anchors it asserts against cannot tell you the model is right about the world.
That check needs live FRED data and is `scripts/validate_history.py`. This one
tells you the machinery is sound, which is the precondition for that check
meaning anything.
"""

import numpy as np
import pandas as pd
import pytest

from conftest import level_from_yoy
from core import regime as R

# (date, value) anchors, linearly interpolated between. Approximate US CPI
# year-over-year and real GDP growth, in percent.
INFLATION = [
    ("1960-01", 1.5), ("1965-01", 1.6), ("1970-01", 5.9), ("1974-12", 11.0),
    ("1976-12", 5.0), ("1980-03", 13.5), ("1983-06", 3.2), ("1986-12", 1.9),
    ("1990-12", 5.4), ("1994-06", 2.6), ("2000-06", 3.4), ("2002-06", 1.6),
    ("2006-06", 3.2), ("2008-07", 5.6), ("2009-07", -2.1), ("2011-09", 3.9),
    ("2013-06", 1.5), ("2014-06", 2.1), ("2015-06", 0.1),
    ("2018-06", 2.4), ("2020-01", 2.3),
    ("2020-05", 0.1),
    ("2021-09", 5.4), ("2022-06", 9.1), ("2023-06", 3.0), ("2024-12", 2.9),
    ("2026-08", 2.5),
]

GROWTH = [
    ("1960-01", 2.5), ("1962-06", 6.1), ("1966-06", 6.6), ("1970-06", 0.2),
    ("1973-06", 5.6), ("1975-06", -0.5), ("1978-06", 5.5), ("1980-06", -0.3),
    ("1982-12", -1.8), ("1984-06", 7.2), ("1987-06", 3.5), ("1991-03", -0.1),
    ("1995-06", 2.7), ("1999-06", 4.8), ("2001-09", 0.2), ("2004-06", 3.9),
    ("2007-06", 2.0), ("2009-06", -3.9), ("2010-06", 2.6), ("2013-01", 1.4),
    ("2015-06", 2.9), ("2018-06", 3.0), ("2020-01", 2.2), ("2020-04", -8.0),
    ("2020-09", -2.0), ("2021-04", 12.0),
    ("2021-12", 5.7), ("2022-09", 1.4), ("2023-06", 2.4), ("2024-12", 2.8),
    ("2026-08", 2.0),
]

INDEX = pd.date_range("1960-01-31", "2026-08-31", freq="ME")


# Month-to-month wiggle, in percentage points. Real CPI year-over-year moves
# ~0.3pp between prints from seasonal and energy noise alone, and industrial
# production more. A near-noiseless fixture is not a gentler test, it is a
# different one: linear ramps between distant anchors have tiny 3-month
# momentum, so almost every month would land on Transition for reasons the
# real series would not.
NOISE_SD = 0.32


def _interpolate(anchors, seed, noise=NOISE_SD):
    """Anchors -> a monthly path with independent noise per series."""
    at = pd.Series(
        {pd.Timestamp(d) + pd.offsets.MonthEnd(0): v for d, v in anchors},
        dtype="float64")
    path = at.reindex(at.index.union(INDEX)).interpolate("time").reindex(INDEX)
    rng = np.random.default_rng(seed)
    return path + rng.normal(0.0, noise, len(INDEX))


def _jitter(seed, sd=NOISE_SD):
    return np.random.default_rng(seed).normal(0.0, sd, len(INDEX))


@pytest.fixture(scope="module")
def raw():
    infl = _interpolate(INFLATION, 1)
    grow = _interpolate(GROWTH, 2)
    mk = lambda v: pd.Series(np.asarray(v, dtype="float64"), index=INDEX)
    return {
        # Growth axis. Industrial production and retail sales run hotter than
        # GDP; payrolls lag and run cooler; unemployment moves the other way.
        "Industrial_Production": mk(level_from_yoy(grow * 1.4 + _jitter(11))),
        "Nonfarm_Payrolls": mk(level_from_yoy(grow * 0.5 + 0.3 + _jitter(12, 0.1))),
        "Retail_Sales": mk(level_from_yoy(grow * 1.1 + infl * 0.4 + _jitter(13))),
        "GDP_Growth": mk(grow + _jitter(14, 0.2)),
        "Unemployment": mk(6.0 - grow * 0.6 + _jitter(15, 0.15)),
        "Consumer_Sentiment": mk(88.0 + grow * 3.0 - infl * 1.5 + _jitter(16, 2.0)),
        # Inflation axis.
        "Inflation_CPI": mk(level_from_yoy(infl)),
        "Core_CPI": mk(level_from_yoy(infl * 0.8 + 0.4 + _jitter(17, 0.15))),
        "Breakeven_10Y": mk(infl * 0.55 + 1.0 + _jitter(18, 0.2)),
    }


@pytest.fixture(scope="module")
def frame(raw):
    return R.build(raw)


# Windows chosen where the MOMENTUM of both axes is unambiguous, which is not
# the same as the whole of a popularly-named episode. Two cases are worth
# spelling out, because they are where a momentum framework and everyday usage
# genuinely disagree:
#
#   * H2 2022. CPI peaked in June and fell after, so by momentum the second
#     half of 2022 was disinflationary contraction, not stagflation.
#   * "Goldilocks 2013-2015" is a statement about LEVELS -- decent growth,
#     inflation below target -- not about momentum. Measured on this fixture
#     that whole stretch has a median momentum radius of 0.19, below
#     CALL_RADIUS, so the model correctly declines to call it. The window used
#     here is the 2014-15 oil crash instead, where inflation was genuinely
#     falling fast while growth firmed. This is a real property of the
#     framework rather than a defect, and worth knowing before reading the
#     dashboard: quiet years get no call.
#
# Dates also allow for the publication lag -- the model's call for a month
# reflects what was knowable then, so it turns a month or two after the
# reference data does.
WINDOWS = [
    ("1978-09", "1980-09", R.STAGFLATION, "second oil shock into recession"),
    ("2008-11", "2009-09", R.DEFLATION, "GFC: growth and prices collapsing"),
    ("2014-09", "2015-09", R.GOLDILOCKS, "oil crash: inflation falling, growth firm"),
    ("2020-05", "2020-09", R.DEFLATION, "COVID shutdown"),
    ("2020-12", "2021-10", R.REFLATION, "reopening boom, inflation building"),
    ("2022-02", "2022-08", R.STAGFLATION, "inflation peak, growth slowing"),
]


def test_frame_covers_the_whole_period(frame):
    assert not frame.empty
    # 120-month z-window plus 60 min_periods plus the Delta horizon eats the
    # first few years; everything after should be there.
    assert frame.index[0].year <= 1970
    assert frame.index[-1].year >= 2026
    assert frame.index.is_monotonic_increasing


@pytest.mark.parametrize("start,end,expected,why", WINDOWS)
def test_window_is_mostly_the_expected_regime(frame, start, end, expected, why):
    window = frame.loc[start:end]
    assert len(window) >= 5, f"not enough months in {start}..{end}"
    quadrants = [R.quadrant(row["growth_delta"], row["inflation_delta"])
                 for _, row in window.iterrows()]
    hits = quadrants.count(expected)
    assert hits / len(quadrants) >= 0.7, (
        f"{why}: {hits}/{len(quadrants)} months matched {expected}; "
        f"got {pd.Series(quadrants).value_counts().to_dict()}")


def test_the_scoring_harness_agrees(frame, monkeypatch):
    """scripts/validate_history.py's scorer, on the same frame.

    Runs the real function rather than a copy, so a bug in the harness -- the
    thing that will be used to tune the model against live FRED data -- fails
    here rather than silently reporting a good number.
    """
    import scripts.validate_history as vh
    monkeypatch.setattr(vh, "EXPECTED", WINDOWS)
    table, overall = vh.score(frame)
    assert len(table) == len(WINDOWS)
    assert table["months"].min() > 0, "a window found no data"
    assert overall >= 0.7, f"{overall:.1%}\n{table.to_string(index=False)}"


def test_transition_share_is_not_the_whole_history(frame):
    """A model that says "Transition" everywhere would score well on the
    windows above by never being wrong. Guard against that."""
    share = (frame["quadrant"] == R.TRANSITION).mean()
    assert share < 0.5, f"{share:.1%} of all months are undecided"


def test_the_2022_inflation_peak_flips_the_inflation_delta(frame):
    """A specific, falsifiable claim: CPI momentum turns negative after the
    mid-2022 peak. If the sign does not flip, the Delta is measuring the wrong
    thing -- which is exactly what delta-of-z did."""
    before = frame.loc["2022-02":"2022-07", "inflation_delta"].mean()
    after = frame.loc["2023-01":"2023-09", "inflation_delta"].mean()
    assert before > 0 > after, f"before={before:.3f} after={after:.3f}"


def test_the_covid_trough_is_the_deepest_growth_reading(frame):
    """1960-2026, and the sharpest growth contraction should be spring 2020."""
    trough = frame["growth_delta"].idxmin()
    assert 2020 <= trough.year <= 2021, trough
